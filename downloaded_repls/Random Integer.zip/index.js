function randomInteger(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

console.log("A random integer between 0 and 10");
console.log(randomInteger(0, 10));
console.log("Another random integer between 0 and 10");
console.log(randomInteger(0, 10));
console.log("A random number between 600 and 1200");
console.log(randomInteger(600, 1200));
