const cakes = document.querySelectorAll('.cake');
let lastCake = 0;
let time = 10;

function chooseCake(cakes) {
  const index = Math.floor(Math.random() * 2);
  const cake = cakes[index];
  if (cake === lastCake) {
    return chooseCake(cakes);
  }
  lastCake = cake;
  return cake;
}

function setDelay(difficulty){
  return 1000;
}

function gameOver() {
  if(time > 0){
    let timeoutId = showUp();
    return timeoutId;
  } else {
    let gameStopped = stopGame();
    return gameStopped;
  }
}
  
function showUp() {
  let delay = setDelay("easy");
  const cake = chooseCake(cakes);
  return showAndHide(cake, delay);
}

function showAndHide(cake, delay){
  toggleVisibility(cake);
  const timeoutID = setTimeout(() => {
    toggleVisibility(cake);
    gameOver();
  }, delay);
  return timeoutID;
}

function toggleVisibility(cake){
  cake.classList.toggle('show');
  return cake;
}

showUp();