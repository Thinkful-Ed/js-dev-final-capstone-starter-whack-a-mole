const holes = document.querySelectorAll('.hole');

let lastHole = 0;

function randomInteger(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function chooseHole(holes) {
  const index = randomInteger(0, 2);
  const hole = holes[index];
  if (hole === lastHole) {
    return chooseHole(holes);
  }
  lastHole = hole;
  return hole;
}

// example
let hole = chooseHole(holes);

// highlight random hole
hole.classList.toggle("highlight");
console.log(hole.innerHTML);
console.log(hole.classList);

// choose another hole and highlight it too
hole = chooseHole(holes);
hole.classList.toggle("highlight");
console.log(hole.innerHTML);
console.log(hole.classList);